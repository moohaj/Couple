# باهم

یه اپ خصوصی برای دو نفر: شمارندهٔ روزهای با هم بودن (تقویم جلالی)، گفتگو و یادداشت، آلبوم خاطره‌ها با عکس، برنامه‌ها و مناسبت‌ها.
یه کد برای هر دو گوشی؛ از مرورگر نصب می‌شه (PWA)، پس روی آیفون و اندروید هر دو کار می‌کنه و به App Store و Play Store نیازی نیست.

## چیزی که لازم داری

یه جا که ۲۴ ساعته روشن باشه و هر دو گوشی بهش برسن، **با آدرس https**. HTTPS شرطه، چون بدونش iOS و Chrome اجازهٔ نصب اپ و service worker نمی‌دن.

## اجرای محلی (برای امتحان)

```bash
pip install -r requirements.txt
python app.py          # http://localhost:5055
```

## روی سرور (پیشنهادی)

۱. یه VPS کوچیک با Docker بگیر و دامنه‌ای بهش وصل کن (رکورد A).
۲. توی `Caddyfile` به‌جای `YOUR_DOMAIN` دامنه‌ات رو بنویس.
۳. `docker compose up -d --build`

Caddy خودش گواهی HTTPS می‌گیره. داده‌ها (دیتابیس و عکس‌ها) توی volume به اسم `bahamm-data` می‌مونن.

بدون Docker:

```bash
pip install -r requirements.txt
BAHAMM_PROXY=1 BAHAMM_SECURE_COOKIE=1 gunicorn -w 2 --threads 4 -b 127.0.0.1:5055 app:app
```

و جلوش nginx یا Caddy با HTTPS بذار.

## روی Railway

۱. پوشهٔ پروژه رو توی یه مخزن GitHub بذار (فایل `.gitignore` آماده‌ست).
۲. توی Railway: **New Project ← Deploy from GitHub repo** و همین مخزن رو انتخاب کن. Railway خودش `Dockerfile` و `railway.json` رو می‌شناسه.
۳. **مهم:** سرویس رو باز کن، از **Volumes** یه volume اضافه کن و **Mount path** رو `/data` بذار. بدون این، عکس‌ها و پیام‌ها با هر دیپلوی دوباره پاک می‌شن.
۴. **Settings ← Networking ← Generate Domain** رو بزن تا لینک https بگیری.
۵. لینک رو باز کن و «ساخت فضا» رو بزن.

متغیر محیطی اضافه‌ای لازم نیست. `PORT` رو Railway خودش می‌ده و بقیه توی `Dockerfile` ست شده.

## روی هاست cPanel (بدون Docker)

هاست باید بخش **Setup Python App** داشته باشه (پایتون ۳.۹ یا بالاتر) و برای دامنه‌ات SSL فعال باشه (معمولاً AutoSSL رایگانه).

۱. فایل‌های پروژه رو توی یه پوشه **بیرون از public_html** آپلود و extract کن، مثلاً `~/bahamm`.
۲. توی cPanel: **Setup Python App ← Create Application**
   - Python version: بالاترین نسخه‌ای که هست
   - Application root: `bahamm`
   - Application URL: دامنه یا زیردامنه‌ات (مثلاً `us.example.com`)
   - Application startup file: `passenger_wsgi.py`
   - Application Entry point: `application`
۳. بعد از ساخت، پایین همون صفحه **Environment variables** رو باز کن و اضافه کن:
   - `BAHAMM_SECURE_COOKIE` = `1`
   - `BAHAMM_PROXY` = `1`
۴. فایل `requirements.txt` رو توی همون صفحه انتخاب کن و **Run Pip Install** بزن (اگه گزینه‌اش نبود، از Terminal هاست: `pip install -r requirements.txt` داخل virtualenv که cPanel بالای صفحه نشون می‌ده).
۵. **Restart** رو بزن و آدرس رو توی مرورگر باز کن.

اگه صفحهٔ خطا اومد، لاگ رو توی `~/bahamm/stderr.log` یا بخش Errors در cPanel ببین.

## شروع استفاده

۱. تو: «ساخت فضا» رو بزن، نام و رمز و تاریخ شروع رابطه رو وارد کن.
۲. صفحهٔ خانه یه کد دعوت نشون می‌ده. با «ارسال دعوت» برای شریکت بفرست.
۳. اون: «پیوستن» رو بزنه، کد و نام و رمز خودش رو بده.
۴. از اون به بعد، صفحهٔ ورود اسم هر دو نفر رو نشون می‌ده؛ فقط اسم خودت رو می‌زنی و رمز می‌نویسی.

## نصب روی گوشی

- **آیفون:** حتماً توی Safari باز کن ← دکمهٔ اشتراک‌گذاری ← Add to Home Screen.
- **اندروید:** توی Chrome منوی سه‌نقطه ← Install app.

## تنظیمات سرور (متغیرهای محیطی)

| متغیر | پیش‌فرض | توضیح |
|---|---|---|
| `BAHAMM_DATA` | `./data` | پوشهٔ دیتابیس، عکس‌ها و کلید نشست |
| `BAHAMM_MAX_COUPLES` | `1` | سرور فقط برای یک زوج ساخته می‌شه؛ کسی دیگه نمی‌تونه فضا بسازه |
| `BAHAMM_PROXY` | `0` | پشت nginx یا Caddy روی `1` بذار |
| `BAHAMM_SECURE_COOKIE` | `0` | روی HTTPS روی `1` بذار |
| `PORT` | `5055` | پورت اجرای مستقیم |

## نکته‌های امنیتی

- صفحهٔ ورود فقط **نام** دو عضو رو بدون رمز نشون می‌ده تا انتخاب سریع باشه. بقیهٔ اطلاعات بدون ورود در دسترس نیست.
- رمزها هش می‌شن و ورودِ ناموفقِ پشت‌سرهم موقتاً قفل می‌شه.
- عکس‌ها فقط برای کسی که وارد شده باز می‌شن، نه با لینک عمومی.

## پشتیبان‌گیری

کل اطلاعات توی پوشهٔ `BAHAMM_DATA` هست. از همین پوشه (یا volume داکر) هر وقت خواستی کپی بگیر.
