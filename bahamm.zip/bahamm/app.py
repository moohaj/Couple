"""باهم — اپ خصوصی دو نفره (Flask + SQLite).

اجرا:  python app.py            (برای تست)
        gunicorn -w 2 -b 0.0.0.0:5055 app:app   (برای سرور)
"""
import io
import os
import re
import secrets
import sqlite3
import time
import uuid
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path

from flask import Flask, g, jsonify, request, send_file, send_from_directory, session
from PIL import Image, ImageOps
from werkzeug.security import check_password_hash, generate_password_hash

try:  # اختیاری: پشتیبانی از HEIC اگر pillow-heif نصب باشد
    import pillow_heif

    pillow_heif.register_heif_opener()
except Exception:
    pass

BASE = Path(__file__).resolve().parent
DATA = Path(os.environ.get("BAHAMM_DATA", BASE / "data"))
UPLOADS = DATA / "uploads"
DATA.mkdir(parents=True, exist_ok=True)
UPLOADS.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA / "bahamm.db"
MAX_COUPLES = int(os.environ.get("BAHAMM_MAX_COUPLES", "1"))
CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"


def _secret_key():
    p = DATA / "secret.key"
    if not p.exists():
        p.write_text(secrets.token_hex(32))
        try:
            p.chmod(0o600)
        except OSError:
            pass
    return p.read_text().strip()


app = Flask(__name__, static_folder=str(BASE / "static"), static_url_path="/static")
app.config.update(
    SECRET_KEY=_secret_key(),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("BAHAMM_SECURE_COOKIE", "0") == "1",
    PERMANENT_SESSION_LIFETIME=60 * 60 * 24 * 365,
    MAX_CONTENT_LENGTH=30 * 1024 * 1024,
    SEND_FILE_MAX_AGE_DEFAULT=0,
)
app.json.ensure_ascii = False
if os.environ.get("BAHAMM_PROXY") == "1":  # پشت Caddy / nginx
    from werkzeug.middleware.proxy_fix import ProxyFix

    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

SCHEMA = """
CREATE TABLE IF NOT EXISTS couples(
  id INTEGER PRIMARY KEY,
  invite_code TEXT UNIQUE NOT NULL,
  start_date TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY,
  couple_id INTEGER NOT NULL REFERENCES couples(id),
  name TEXT NOT NULL,
  name_key TEXT UNIQUE NOT NULL,
  pw_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY,
  couple_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_couple ON messages(couple_id, id);
CREATE TABLE IF NOT EXISTS notes(
  id INTEGER PRIMARY KEY,
  couple_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL DEFAULT '',
  body TEXT NOT NULL DEFAULT '',
  pinned INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS memories(
  id INTEGER PRIMARY KEY,
  couple_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL DEFAULT '',
  body TEXT NOT NULL DEFAULT '',
  date TEXT NOT NULL,
  photo TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS plans(
  id INTEGER PRIMARY KEY,
  couple_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'todo',
  due_date TEXT,
  done INTEGER NOT NULL DEFAULT 0,
  done_at TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS occasions(
  id INTEGER PRIMARY KEY,
  couple_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  date TEXT NOT NULL,
  yearly INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);
"""


def init_db():
    con = sqlite3.connect(DB_PATH)
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript(SCHEMA)
    con.commit()
    con.close()


init_db()


def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH, timeout=10)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    con = g.pop("db", None)
    if con is not None:
        con.close()


# ---------------------------------------------------------------- helpers
class ApiError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.message = message
        self.status = status


@app.errorhandler(ApiError)
def handle_api_error(e):
    return jsonify({"error": e.message}), e.status


@app.errorhandler(413)
def too_large(_e):
    return jsonify({"error": "حجم فایل بیشتر از حد مجازه (حداکثر ۳۰ مگابایت)"}), 413


@app.errorhandler(404)
def not_found(_e):
    if request.path.startswith("/api/"):
        return jsonify({"error": "پیدا نشد"}), 404
    return "Not found", 404


@app.errorhandler(405)
def bad_method(_e):
    return jsonify({"error": "این درخواست مجاز نیست"}), 405


def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def today_utc():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def clean(value, maxlen):
    return (value if isinstance(value, str) else "").strip()[:maxlen]


def name_key(name):
    n = name.replace("ي", "ی").replace("ك", "ک").replace("‌", " ")
    return re.sub(r"\s+", " ", n).strip().casefold()


def valid_date(value, required=False):
    if value in (None, ""):
        if required:
            raise ApiError("تاریخ لازمه")
        return None
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        raise ApiError("تاریخ معتبر نیست")
    try:
        datetime.strptime(value, "%Y-%m-%d")
    except ValueError:
        raise ApiError("تاریخ معتبر نیست")
    return value


def body_json():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        raise ApiError("درخواست نامعتبره")
    return data


def new_code():
    con = db()
    while True:
        code = "".join(secrets.choice(CODE_ALPHABET) for _ in range(6))
        if not con.execute("SELECT 1 FROM couples WHERE invite_code=?", (code,)).fetchone():
            return code


_attempts = {}


def throttle_check(key, limit=8, window=300):
    t = time.time()
    arr = [x for x in _attempts.get(key, []) if t - x < window]
    _attempts[key] = arr
    if len(arr) >= limit:
        raise ApiError("تلاش ناموفق زیاد بود؛ چند دقیقه صبر کن و دوباره امتحان کن", 429)


def throttle_fail(key):
    _attempts.setdefault(key, []).append(time.time())


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        uid = session.get("uid")
        user = db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone() if uid else None
        if not user:
            session.clear()
            raise ApiError("وارد نشدی", 401)
        g.user = user
        g.cid = user["couple_id"]
        return fn(*args, **kwargs)

    return wrapper


def couple_payload(cid):
    con = db()
    c = con.execute("SELECT * FROM couples WHERE id=?", (cid,)).fetchone()
    members = con.execute("SELECT id, name FROM users WHERE couple_id=? ORDER BY id", (cid,)).fetchall()
    complete = len(members) >= 2
    return {
        "id": c["id"],
        "start_date": c["start_date"],
        "invite_code": None if complete else c["invite_code"],
        "complete": complete,
        "members": [{"id": m["id"], "name": m["name"]} for m in members],
    }


def me_payload(user):
    return {"user": {"id": user["id"], "name": user["name"]}, "couple": couple_payload(user["couple_id"])}


def check_password(pw):
    if not isinstance(pw, str) or len(pw) < 6:
        raise ApiError("رمز عبور باید حداقل ۶ کاراکتر باشه")
    if len(pw) > 200:
        raise ApiError("رمز عبور خیلی طولانیه")


def check_name(name):
    if len(name) < 2:
        raise ApiError("نام باید حداقل ۲ حرف باشه")


def start_session(uid):
    session.clear()
    session.permanent = True
    session["uid"] = uid


# ---------------------------------------------------------------- auth
@app.post("/api/create")
def create_space():
    d = body_json()
    name = clean(d.get("name"), 30)
    check_name(name)
    check_password(d.get("password"))
    start = valid_date(d.get("start_date"))
    con = db()
    if con.execute("SELECT COUNT(*) FROM couples").fetchone()[0] >= MAX_COUPLES:
        raise ApiError(
            "این سرور فقط برای یک زوج تنظیم شده و فضاش پر شده. "
            "اگه خودت راه‌اندازیش کردی، مقدار BAHAMM_MAX_COUPLES رو بیشتر کن.",
            403,
        )
    if con.execute("SELECT 1 FROM users WHERE name_key=?", (name_key(name),)).fetchone():
        raise ApiError("این نام قبلاً استفاده شده؛ یه نام دیگه انتخاب کن", 409)
    cid = con.execute(
        "INSERT INTO couples(invite_code, start_date, created_at) VALUES(?,?,?)",
        (new_code(), start, now()),
    ).lastrowid
    uid = con.execute(
        "INSERT INTO users(couple_id, name, name_key, pw_hash, created_at) VALUES(?,?,?,?,?)",
        (cid, name, name_key(name), generate_password_hash(d["password"]), now()),
    ).lastrowid
    con.commit()
    start_session(uid)
    user = con.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    return jsonify(me_payload(user))


@app.post("/api/join")
def join_space():
    d = body_json()
    ip = request.remote_addr or "?"
    throttle_check(("join", ip))
    code = re.sub(r"[^A-Z0-9]", "", clean(d.get("code"), 20).upper())
    name = clean(d.get("name"), 30)
    check_name(name)
    check_password(d.get("password"))
    con = db()
    couple = con.execute("SELECT * FROM couples WHERE invite_code=?", (code,)).fetchone()
    if not couple:
        throttle_fail(("join", ip))
        raise ApiError("کد دعوت درست نیست", 404)
    count = con.execute("SELECT COUNT(*) FROM users WHERE couple_id=?", (couple["id"],)).fetchone()[0]
    if count >= 2:
        raise ApiError("این فضا دو نفره‌ست و پر شده", 403)
    if con.execute("SELECT 1 FROM users WHERE name_key=?", (name_key(name),)).fetchone():
        raise ApiError("این نام قبلاً استفاده شده؛ یه نام دیگه انتخاب کن", 409)
    uid = con.execute(
        "INSERT INTO users(couple_id, name, name_key, pw_hash, created_at) VALUES(?,?,?,?,?)",
        (couple["id"], name, name_key(name), generate_password_hash(d["password"]), now()),
    ).lastrowid
    con.commit()
    start_session(uid)
    user = con.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    return jsonify(me_payload(user))


@app.get("/api/members")
def public_members():
    """فقط نام اعضا، برای انتخاب سریع توی صفحه‌ی ورود (بدون هیچ اطلاعات دیگه‌ای)."""
    rows = db().execute("SELECT name FROM users ORDER BY id LIMIT 4").fetchall()
    return jsonify({"names": [r["name"] for r in rows]})


@app.post("/api/login")
def login():
    d = body_json()
    key = name_key(clean(d.get("name"), 30))
    tkey = ("login", request.remote_addr or "?", key)
    throttle_check(tkey)
    user = db().execute("SELECT * FROM users WHERE name_key=?", (key,)).fetchone()
    pw = d.get("password")
    if not user or not isinstance(pw, str) or not check_password_hash(user["pw_hash"], pw):
        throttle_fail(tkey)
        raise ApiError("نام یا رمز عبور درست نیست", 401)
    _attempts.pop(tkey, None)
    start_session(user["id"])
    return jsonify(me_payload(user))


@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify({"ok": True})


@app.get("/api/me")
@login_required
def me():
    return jsonify(me_payload(g.user))


@app.patch("/api/me")
@login_required
def update_me():
    d = body_json()
    con = db()
    if "name" in d:
        name = clean(d["name"], 30)
        check_name(name)
        other = con.execute(
            "SELECT id FROM users WHERE name_key=? AND id<>?", (name_key(name), g.user["id"])
        ).fetchone()
        if other:
            raise ApiError("این نام قبلاً استفاده شده", 409)
        con.execute("UPDATE users SET name=?, name_key=? WHERE id=?", (name, name_key(name), g.user["id"]))
    if "new_password" in d:
        if not check_password_hash(g.user["pw_hash"], d.get("old_password") or ""):
            raise ApiError("رمز فعلی درست نیست", 403)
        check_password(d["new_password"])
        con.execute("UPDATE users SET pw_hash=? WHERE id=?", (generate_password_hash(d["new_password"]), g.user["id"]))
    con.commit()
    user = con.execute("SELECT * FROM users WHERE id=?", (g.user["id"],)).fetchone()
    return jsonify(me_payload(user))


@app.patch("/api/couple")
@login_required
def update_couple():
    d = body_json()
    if "start_date" in d:
        db().execute("UPDATE couples SET start_date=? WHERE id=?", (valid_date(d["start_date"]), g.cid))
        db().commit()
    return jsonify(couple_payload(g.cid))


# ---------------------------------------------------------------- chat
def msg_json(r):
    return {"id": r["id"], "user_id": r["user_id"], "body": r["body"], "created_at": r["created_at"]}


@app.get("/api/messages")
@login_required
def messages_list():
    con = db()
    after = request.args.get("after", type=int)
    before = request.args.get("before", type=int)
    limit = max(1, min(request.args.get("limit", 60, type=int), 200))
    has_more = False
    if after:
        rows = con.execute(
            "SELECT * FROM messages WHERE couple_id=? AND id>? ORDER BY id LIMIT 200", (g.cid, after)
        ).fetchall()
    else:
        sql = "SELECT * FROM messages WHERE couple_id=?" + (" AND id<?" if before else "") + " ORDER BY id DESC LIMIT ?"
        params = (g.cid, before, limit + 1) if before else (g.cid, limit + 1)
        rows = con.execute(sql, params).fetchall()
        has_more = len(rows) > limit
        rows = list(reversed(rows[:limit]))
    return jsonify({"messages": [msg_json(r) for r in rows], "has_more": has_more})


@app.post("/api/messages")
@login_required
def messages_send():
    text = clean(body_json().get("body"), 2000)
    if not text:
        raise ApiError("پیام خالیه")
    con = db()
    mid = con.execute(
        "INSERT INTO messages(couple_id, user_id, body, created_at) VALUES(?,?,?,?)",
        (g.cid, g.user["id"], text, now()),
    ).lastrowid
    con.commit()
    return jsonify(msg_json(con.execute("SELECT * FROM messages WHERE id=?", (mid,)).fetchone())), 201


# ---------------------------------------------------------------- generic CRUD
def build_values(spec, data, partial=False):
    out = {}
    for col, opt in spec.items():
        typ = opt["type"]
        if col not in data:
            if partial:
                continue
            if opt.get("required"):
                raise ApiError(opt.get("msg", "یکی از فیلدها خالیه"))
            out[col] = opt.get("default")
            continue
        v = data[col]
        if typ == "str":
            v = clean(v, opt["max"])
            if opt.get("required") and not v:
                raise ApiError(opt.get("msg", "یکی از فیلدها خالیه"))
        elif typ == "date":
            v = valid_date(v, required=opt.get("required", False))
        elif typ == "bool":
            v = 1 if v else 0
        elif typ == "enum":
            if v not in opt["values"]:
                raise ApiError("مقدار نامعتبره")
        out[col] = v
    return out


def row_json(row, bools=()):
    d = {k: row[k] for k in row.keys() if k != "couple_id"}
    for b in bools:
        d[b] = bool(d[b])
    return d


def register_crud(path, table, spec, order, bools=(), touch=None):
    cols = list(spec)

    def list_view():
        rows = db().execute(f"SELECT * FROM {table} WHERE couple_id=? ORDER BY {order}", (g.cid,)).fetchall()
        return jsonify({path: [row_json(r, bools) for r in rows]})

    def create_view():
        vals = build_values(spec, body_json())
        if table == "notes" and not (vals["title"] or vals["body"]):
            raise ApiError("یادداشت خالیه")
        extra = {"couple_id": g.cid, "user_id": g.user["id"], "created_at": now()}
        if touch:
            extra[touch] = now()
        vals.update(extra)
        con = db()
        rid = con.execute(
            f"INSERT INTO {table}({','.join(vals)}) VALUES({','.join('?' * len(vals))})", list(vals.values())
        ).lastrowid
        con.commit()
        row = con.execute(f"SELECT * FROM {table} WHERE id=?", (rid,)).fetchone()
        return jsonify(row_json(row, bools)), 201

    def update_view(rid):
        con = db()
        old = con.execute(f"SELECT * FROM {table} WHERE id=? AND couple_id=?", (rid, g.cid)).fetchone()
        if not old:
            raise ApiError("پیدا نشد", 404)
        vals = build_values(spec, body_json(), partial=True)
        if table == "plans" and "done" in vals and vals["done"] != old["done"]:
            vals["done_at"] = now() if vals["done"] else None
        if touch:
            vals[touch] = now()
        if vals:
            sets = ",".join(f"{k}=?" for k in vals)
            con.execute(f"UPDATE {table} SET {sets} WHERE id=? AND couple_id=?", [*vals.values(), rid, g.cid])
            con.commit()
        row = con.execute(f"SELECT * FROM {table} WHERE id=?", (rid,)).fetchone()
        return jsonify(row_json(row, bools))

    def delete_view(rid):
        con = db()
        cur = con.execute(f"DELETE FROM {table} WHERE id=? AND couple_id=?", (rid, g.cid))
        con.commit()
        if not cur.rowcount:
            raise ApiError("پیدا نشد", 404)
        return jsonify({"ok": True})

    base = f"/api/{path}"
    app.add_url_rule(base, f"{path}_list", login_required(list_view), methods=["GET"])
    app.add_url_rule(base, f"{path}_create", login_required(create_view), methods=["POST"])
    app.add_url_rule(base + "/<int:rid>", f"{path}_update", login_required(update_view), methods=["PUT", "PATCH"])
    app.add_url_rule(base + "/<int:rid>", f"{path}_delete", login_required(delete_view), methods=["DELETE"])


register_crud(
    "notes",
    "notes",
    {
        "title": {"type": "str", "max": 120, "default": ""},
        "body": {"type": "str", "max": 10000, "default": ""},
        "pinned": {"type": "bool", "default": 0},
    },
    "pinned DESC, updated_at DESC, id DESC",
    bools=("pinned",),
    touch="updated_at",
)
register_crud(
    "plans",
    "plans",
    {
        "title": {"type": "str", "max": 200, "required": True, "msg": "عنوان برنامه خالیه"},
        "kind": {"type": "enum", "values": ("todo", "trip", "date", "wish"), "default": "todo"},
        "due_date": {"type": "date"},
        "done": {"type": "bool", "default": 0},
    },
    "done, due_date IS NULL, due_date, id DESC",
    bools=("done",),
)
register_crud(
    "occasions",
    "occasions",
    {
        "title": {"type": "str", "max": 120, "required": True, "msg": "عنوان مناسبت خالیه"},
        "date": {"type": "date", "required": True},
        "yearly": {"type": "bool", "default": 1},
    },
    "date, id",
    bools=("yearly",),
)


# ---------------------------------------------------------------- memories (photos)
def save_photo(storage):
    raw = storage.read()
    if not raw:
        raise ApiError("فایل عکس خالیه")
    try:
        im = Image.open(io.BytesIO(raw))
        im = ImageOps.exif_transpose(im).convert("RGB")
    except Exception:
        raise ApiError("این فایل عکس معتبری نیست")
    name = uuid.uuid4().hex
    full = im.copy()
    full.thumbnail((1800, 1800))
    full.save(UPLOADS / f"{name}.jpg", "JPEG", quality=86, optimize=True, progressive=True)
    thumb = im.copy()
    thumb.thumbnail((720, 720))
    thumb.save(UPLOADS / f"{name}_t.jpg", "JPEG", quality=80, optimize=True)
    return name


def delete_photo(name):
    if not name:
        return
    for suffix in ("", "_t"):
        try:
            (UPLOADS / f"{name}{suffix}.jpg").unlink()
        except OSError:
            pass


def memory_json(r):
    return {
        "id": r["id"],
        "user_id": r["user_id"],
        "title": r["title"],
        "body": r["body"],
        "date": r["date"],
        "photo": r["photo"],
        "created_at": r["created_at"],
    }


@app.get("/api/memories")
@login_required
def memories_list():
    rows = db().execute("SELECT * FROM memories WHERE couple_id=? ORDER BY date DESC, id DESC", (g.cid,)).fetchall()
    return jsonify({"memories": [memory_json(r) for r in rows]})


def memory_fields(form, partial=False):
    out = {}
    if "title" in form or not partial:
        out["title"] = clean(form.get("title"), 120)
    if "body" in form or not partial:
        out["body"] = clean(form.get("body"), 5000)
    if "date" in form or not partial:
        out["date"] = valid_date(form.get("date") or today_utc(), required=True)
    return out


@app.post("/api/memories")
@login_required
def memories_create():
    vals = memory_fields(request.form)
    file = request.files.get("photo")
    photo = save_photo(file) if file and file.filename else None
    if not (vals["title"] or vals["body"] or photo):
        raise ApiError("یه عنوان، توضیح یا عکس اضافه کن")
    con = db()
    mid = con.execute(
        "INSERT INTO memories(couple_id, user_id, title, body, date, photo, created_at) VALUES(?,?,?,?,?,?,?)",
        (g.cid, g.user["id"], vals["title"], vals["body"], vals["date"], photo, now()),
    ).lastrowid
    con.commit()
    return jsonify(memory_json(con.execute("SELECT * FROM memories WHERE id=?", (mid,)).fetchone())), 201


@app.route("/api/memories/<int:mid>", methods=["PUT", "POST"])
@login_required
def memories_update(mid):
    con = db()
    old = con.execute("SELECT * FROM memories WHERE id=? AND couple_id=?", (mid, g.cid)).fetchone()
    if not old:
        raise ApiError("پیدا نشد", 404)
    vals = memory_fields(request.form, partial=True)
    file = request.files.get("photo")
    if file and file.filename:
        vals["photo"] = save_photo(file)
        delete_photo(old["photo"])
    elif request.form.get("remove_photo") == "1":
        vals["photo"] = None
        delete_photo(old["photo"])
    if vals:
        sets = ",".join(f"{k}=?" for k in vals)
        con.execute(f"UPDATE memories SET {sets} WHERE id=?", [*vals.values(), mid])
        con.commit()
    return jsonify(memory_json(con.execute("SELECT * FROM memories WHERE id=?", (mid,)).fetchone()))


@app.delete("/api/memories/<int:mid>")
@login_required
def memories_delete(mid):
    con = db()
    old = con.execute("SELECT * FROM memories WHERE id=? AND couple_id=?", (mid, g.cid)).fetchone()
    if not old:
        raise ApiError("پیدا نشد", 404)
    con.execute("DELETE FROM memories WHERE id=?", (mid,))
    con.commit()
    delete_photo(old["photo"])
    return jsonify({"ok": True})


@app.get("/api/photo/<int:mid>")
@login_required
def memory_photo(mid):
    row = db().execute("SELECT photo FROM memories WHERE id=? AND couple_id=?", (mid, g.cid)).fetchone()
    if not row or not row["photo"]:
        raise ApiError("پیدا نشد", 404)
    suffix = "_t" if request.args.get("s") == "t" else ""
    path = UPLOADS / f"{row['photo']}{suffix}.jpg"
    if not path.exists():
        raise ApiError("پیدا نشد", 404)
    resp = send_file(path, mimetype="image/jpeg")
    resp.headers["Cache-Control"] = "private, max-age=31536000, immutable"
    return resp


# ---------------------------------------------------------------- static / PWA
@app.get("/")
def index():
    resp = send_from_directory(app.static_folder, "index.html")
    resp.headers["Cache-Control"] = "no-cache"
    return resp


@app.get("/sw.js")
def service_worker():
    resp = send_from_directory(app.static_folder, "sw.js", mimetype="text/javascript")
    resp.headers["Cache-Control"] = "no-cache"
    resp.headers["Service-Worker-Allowed"] = "/"
    return resp


@app.get("/manifest.webmanifest")
def manifest():
    resp = send_from_directory(app.static_folder, "manifest.webmanifest", mimetype="application/manifest+json")
    resp.headers["Cache-Control"] = "no-cache"
    return resp


@app.get("/favicon.ico")
def favicon():
    return send_from_directory(app.static_folder + "/icons", "favicon.png", mimetype="image/png")


@app.get("/healthz")
def healthz():
    return jsonify({"ok": True})


@app.after_request
def security_headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    resp.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
        "script-src 'self'; connect-src 'self'; font-src 'self'; manifest-src 'self'; "
        "worker-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
    )
    if request.path.startswith("/api/"):
        resp.headers.setdefault("Cache-Control", "no-store")
    return resp


if __name__ == "__main__":
    app.run(host=os.environ.get("HOST", "0.0.0.0"), port=int(os.environ.get("PORT", "5055")), debug=False)
