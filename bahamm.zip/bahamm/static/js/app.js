/* باهم — کلاینت (بدون build؛ فقط جاوااسکریپت ساده) */
(() => {
"use strict";
const J = window.Jalali;
const $ = (s, el = document) => el.querySelector(s);

/* ======================================================= utils */
const FA = "۰۱۲۳۴۵۶۷۸۹";
const fa = (v) => String(v).replace(/\d/g, (d) => FA[+d]);
const en = (s) =>
  String(s)
    .replace(/[۰-۹]/g, (d) => FA.indexOf(d))
    .replace(/[٠-٩]/g, (d) => "٠١٢٣٤٥٦٧٨٩".indexOf(d));
const pad = (n) => String(n).padStart(2, "0");
const MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];
const WEEKDAYS = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];
const ORD = ["", "اول", "دوم", "سوم", "چهارم", "پنجم", "ششم", "هفتم", "هشتم", "نهم", "دهم"];

const localIso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const todayIso = () => localIso(new Date());
const utcDays = (iso) => {
  const [y, m, d] = iso.split("-").map(Number);
  return Date.UTC(y, m - 1, d) / 86400000;
};
const diffDays = (a, b) => Math.round(utcDays(b) - utcDays(a));
const timeFa = (iso) => {
  const d = new Date(iso);
  return fa(`${pad(d.getHours())}:${pad(d.getMinutes())}`);
};
function fmtDate(iso, { year = true, weekday = false } = {}) {
  const j = J.isoToJ(iso);
  let s = `${fa(j.jd)} ${MONTHS[j.jm - 1]}`;
  if (year) s += ` ${fa(j.jy)}`;
  if (weekday) {
    const [y, m, d] = iso.split("-").map(Number);
    s = `${WEEKDAYS[new Date(y, m - 1, d).getDay()]} ${s}`;
  }
  return s;
}
function relDays(n) {
  if (n === 0) return "امروز";
  if (n === 1) return "فردا";
  if (n === -1) return "دیروز";
  return n > 0 ? `${fa(n)} روز دیگه` : `${fa(-n)} روز پیش`;
}
function annOn(iso, jy) {
  const j = J.isoToJ(iso);
  return J.jToIso(jy, j.jm, Math.min(j.jd, J.monthLen(jy, j.jm)));
}
function nextOcc(iso, today) {
  const t = J.isoToJ(today);
  for (let y = t.jy; y <= t.jy + 1; y++) {
    const c = annOn(iso, y);
    if (c >= today) return c;
  }
  return annOn(iso, t.jy + 1);
}
function ymd(startIso, endIso) {
  const a = J.isoToJ(startIso), b = J.isoToJ(endIso);
  let y = b.jy - a.jy, m = b.jm - a.jm, d = b.jd - a.jd;
  if (d < 0) {
    m -= 1;
    let pm = b.jm - 1, py = b.jy;
    if (pm < 1) { pm = 12; py -= 1; }
    d += J.monthLen(py, pm);
  }
  if (m < 0) { y -= 1; m += 12; }
  return { y, m, d };
}
const ordinal = (n) => (ORD[n] ? ORD[n] : `${fa(n)}‌ام`);
const isStandalone = () => matchMedia("(display-mode: standalone)").matches || navigator.standalone === true;
const isIOS = () => /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
const isTouch = () => matchMedia("(pointer: coarse)").matches;

/* ======================================================= icons + dom */
const ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  chat: '<path d="M21 11.5a8.5 8.5 0 0 1-12.3 7.6L3 20.5l1.4-5.3A8.5 8.5 0 1 1 21 11.5z"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="m21 16-5-5-9 9"/>',
  list: '<path d="M10 6h11M10 12h11M10 18h11"/><path d="m3.5 6 1.3 1.3L7 5M3.5 12l1.3 1.3L7 11M3.5 18l1.3 1.3L7 17"/>',
  sliders: '<path d="M4 6h9M19 6h1M4 12h3M13 12h7M4 18h11M21 18h-1"/><circle cx="16" cy="6" r="2.2"/><circle cx="10" cy="12" r="2.2"/><circle cx="18" cy="18" r="2.2"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  send: '<path d="M21 3 10 14M21 3l-7 18-4-7-7-4z"/>',
  heart: '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>',
  pin: '<path d="M12 16v5M8 3h8l-1 7 3 4H6l3-4z"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  camera: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
  share: '<circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="m8.2 10.8 7.6-3.6M8.2 13.2l7.6 3.6"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2.5"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
  back: '<path d="m9 6 6 6-6 6"/>',
  down: '<path d="M12 5v14M6 13l6 6 6-6"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  calendar: '<rect x="3.5" y="5" width="17" height="15.5" rx="3"/><path d="M8 3v4M16 3v4M3.5 10h17"/>',
};
function icon(name, fill = false) {
  const s = h("span", { class: "ico" + (fill ? " fill" : ""), "aria-hidden": "true" });
  s.innerHTML = `<svg viewBox="0 0 24 24" focusable="false">${ICONS[name]}</svg>`;
  return s;
}
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v == null || v === false) continue;
      if (k === "class") el.className = v;
      else if (k === "style") Object.assign(el.style, v);
      else if (k.startsWith("on")) el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k in el) el[k] = v;
      else el.setAttribute(k, v === true ? "" : v);
    }
  }
  for (const kid of kids.flat(Infinity)) {
    if (kid == null || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(kid));
  }
  return el;
}

/* ======================================================= toast, sheet, confirm */
let toastTimer;
function toast(msg) {
  const root = $("#toast-root");
  root.textContent = "";
  root.append(h("div", { class: "toast", role: "status" }, msg));
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (root.textContent = ""), 2800);
}

function openSheet(title, build) {
  const root = $("#sheet-root");
  const back = h("div", { class: "backdrop" });
  const body = h("div", { class: "sheet-body" });
  const sheet = h("div", { class: "sheet", role: "dialog", "aria-modal": "true", "aria-label": title });
  let closed = false;
  const close = () => {
    if (closed) return;
    closed = true;
    sheet.classList.remove("in");
    back.classList.remove("in");
    document.removeEventListener("keydown", onKey);
    setTimeout(() => { back.remove(); sheet.remove(); }, 280);
    api_onClose && api_onClose();
  };
  let api_onClose = null;
  const onKey = (e) => { if (e.key === "Escape") close(); };
  sheet.append(
    h("div", { class: "grab" }),
    h("div", { class: "sheet-head" }, h("h2", null, title), h("button", { class: "icon-btn plain", type: "button", "aria-label": "بستن", onclick: close }, icon("x"))),
    body
  );
  back.addEventListener("click", close);
  root.append(back, sheet);
  requestAnimationFrame(() => { back.classList.add("in"); sheet.classList.add("in"); });
  document.addEventListener("keydown", onKey);
  const ctl = { close, body, onClose: (fn) => (api_onClose = fn) };
  build(body, close, ctl);
  return ctl;
}
const sheetOpen = () => !!$("#sheet-root .sheet");

function confirmDialog(title, text, okLabel = "تأیید", danger = false) {
  return new Promise((resolve) => {
    let answered = false;
    openSheet(title, (body, close, ctl) => {
      ctl.onClose(() => { if (!answered) resolve(false); });
      body.append(
        h("p", { class: "sub", style: { marginBottom: "16px", fontSize: "15px" } }, text),
        h("div", { class: "btn-row" },
          h("button", { class: "btn secondary", type: "button", onclick: close }, "انصراف"),
          h("button", { class: "btn", type: "button", style: danger ? { background: "var(--danger)", color: "#fff" } : null, onclick: () => { answered = true; resolve(true); close(); } }, okLabel)
        )
      );
    });
  });
}

/* ======================================================= api */
class ApiErr extends Error { constructor(msg, status) { super(msg); this.status = status; } }
async function api(method, url, body, opts = {}) {
  const init = { method, headers: {}, credentials: "same-origin" };
  if (body instanceof FormData) init.body = body;
  else if (body !== undefined) { init.headers["Content-Type"] = "application/json"; init.body = JSON.stringify(body); }
  let res;
  try { res = await fetch(url, init); } catch { throw new ApiErr("اتصال برقرار نیست؛ اینترنت رو چک کن", 0); }
  let data = null;
  try { data = await res.json(); } catch { /* بدنه‌ی خالی */ }
  if (!res.ok) {
    if (res.status === 401 && !opts.noAuthRedirect) showAuth();
    throw new ApiErr((data && data.error) || "مشکلی پیش اومد؛ دوباره امتحان کن", res.status);
  }
  return data;
}
const fail = (e) => toast(e.message || "مشکلی پیش اومد");

/* ======================================================= state */
const S = { user: null, couple: null, route: "home", viewToken: 0, timers: [], bg: null, lastId: 0, lastSeen: 0, unread: 0, installPrompt: null, chatTab: "chat", plansTab: "plans" };
const seenKey = () => `bahamm.seen.${S.user ? S.user.id : 0}`;
const nameOf = (id) => { const m = S.couple.members.find((x) => x.id === id); return m ? m.name : "—"; };
const partner = () => S.couple.members.find((m) => m.id !== S.user.id);
function setMe(me) {
  S.user = me.user;
  S.couple = me.couple;
  S.lastSeen = Number(localStorage.getItem(seenKey())) || 0;
}
function every(ms, fn) { const t = setInterval(fn, ms); S.timers.push(t); return t; }
function stopTimers() { S.timers.forEach(clearInterval); S.timers = []; }
function markSeen(id) {
  if (id > S.lastSeen) { S.lastSeen = id; try { localStorage.setItem(seenKey(), String(id)); } catch { /* ignore */ } }
  S.unread = 0;
  updateBadge();
}
function updateBadge() {
  const b = $("#chat-badge");
  if (!b) return;
  b.hidden = !S.unread;
  b.textContent = fa(Math.min(S.unread, 99));
}
async function refreshUnread(initial = false) {
  try {
    const r = initial
      ? await api("GET", "/api/messages?limit=100")
      : await api("GET", `/api/messages?after=${S.lastId}`);
    for (const m of r.messages) {
      S.lastId = Math.max(S.lastId, m.id);
      if (m.user_id !== S.user.id && m.id > S.lastSeen) S.unread += 1;
    }
    if (S.route === "chat") markSeen(S.lastId); else updateBadge();
  } catch { /* بی‌صدا */ }
}

/* ======================================================= helpers: pickers, forms */
function segmented(items, value, onPick) {
  const el = h("div", { class: "seg", role: "tablist" });
  items.forEach(([key, label]) => {
    const b = h("button", {
      type: "button", role: "tab", "aria-selected": String(key === value),
      onclick: () => {
        [...el.children].forEach((c) => c.setAttribute("aria-selected", "false"));
        b.setAttribute("aria-selected", "true");
        onPick(key);
      },
    }, label);
    el.append(b);
  });
  return el;
}

function jalaliPicker(initial, { minYear, maxYear } = {}) {
  const nowJ = J.isoToJ(todayIso());
  const cur = initial ? J.isoToJ(initial) : nowJ;
  const minY = Math.min(minYear ?? nowJ.jy - 60, cur.jy);
  const maxY = Math.max(maxYear ?? nowJ.jy + 10, cur.jy);
  const dSel = h("select", { "aria-label": "روز" });
  const mSel = h("select", { "aria-label": "ماه" });
  const ySel = h("select", { "aria-label": "سال" });
  MONTHS.forEach((n, i) => mSel.append(h("option", { value: i + 1 }, n)));
  for (let y = maxY; y >= minY; y--) ySel.append(h("option", { value: y }, fa(y)));
  const fillDays = () => {
    const len = J.monthLen(+ySel.value, +mSel.value);
    const keep = Math.min(+dSel.value || cur.jd, len);
    dSel.textContent = "";
    for (let d = 1; d <= len; d++) dSel.append(h("option", { value: d }, fa(d)));
    dSel.value = String(keep);
  };
  ySel.value = String(cur.jy);
  mSel.value = String(cur.jm);
  fillDays();
  mSel.addEventListener("change", fillDays);
  ySel.addEventListener("change", fillDays);
  return { el: h("div", { class: "jpick" }, dSel, mSel, ySel), get: () => J.jToIso(+ySel.value, +mSel.value, +dSel.value) };
}

function optionalDate(initial, range) {
  let picker = initial ? jalaliPicker(initial, range) : null;
  const wrap = h("div");
  const render = () => {
    wrap.textContent = "";
    if (picker) {
      wrap.append(picker.el, h("button", { class: "btn ghost small", type: "button", style: { marginTop: "6px" }, onclick: () => { picker = null; render(); } }, "حذف تاریخ"));
    } else {
      wrap.append(h("button", { class: "btn secondary small", type: "button", onclick: () => { picker = jalaliPicker(null, range); render(); } }, icon("calendar"), "افزودن تاریخ"));
    }
  };
  render();
  return { el: wrap, get: () => (picker ? picker.get() : null) };
}

function field(label, control, hint) {
  return h("div", { class: "field" }, h("div", { class: "lbl" }, label), control, hint ? h("div", { class: "hint" }, hint) : null);
}
function toggleRow(label, initial, onChange) {
  let on = !!initial;
  const sw = h("button", { class: "switch", type: "button", role: "switch", "aria-checked": String(on), "aria-label": label,
    onclick: () => { on = !on; sw.setAttribute("aria-checked", String(on)); onChange && onChange(on); } });
  return { el: h("div", { class: "toggle-row" }, h("span", { class: "t" }, label), sw), get: () => on };
}
async function withBusy(btn, label, fn) {
  const old = btn.textContent;
  btn.disabled = true;
  if (label) btn.textContent = label;
  try { return await fn(); } finally { btn.disabled = false; btn.textContent = old; }
}
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; } catch {
    const ta = h("textarea", { value: text, style: { position: "fixed", opacity: "0" } });
    document.body.append(ta); ta.select();
    let ok = false;
    try { ok = document.execCommand("copy"); } catch { /* ignore */ }
    ta.remove();
    return ok;
  }
}
async function shareInvite(code) {
  const text = `بیا تو «باهم»!\n${location.origin}\nکد دعوت: ${code}`;
  if (navigator.share) { try { await navigator.share({ text }); return; } catch (e) { if (e.name === "AbortError") return; } }
  toast((await copyText(text)) ? "متن دعوت کپی شد" : "کپی نشد؛ کد رو دستی بفرست");
}
function emptyState(title, text, cta, onCta) {
  return h("div", { class: "empty" }, h("h3", null, title), h("p", null, text), cta ? h("button", { class: "btn", type: "button", onclick: onCta }, icon("plus"), cta) : null);
}

/* ======================================================= auth */
function showAuth() {
  stopTimers();
  if (S.bg) { clearInterval(S.bg); S.bg = null; }
  S.user = null; S.couple = null;
  if (location.hash) history.replaceState(null, "", location.pathname); // بعد از ورود دوباره از خانه شروع کن
  document.querySelectorAll("#sheet-root > *").forEach((n) => n.remove());
  const app = $("#app");
  app.className = "app";
  app.textContent = "";
  let mode = localStorage.getItem("bahamm.known") ? "login" : "create";
  const card = h("div", { class: "auth-card" });

  const renderCard = () => {
    card.textContent = "";
    card.append(
      segmented([["create", "ساخت فضا"], ["join", "پیوستن"], ["login", "ورود"]], mode, (k) => { mode = k; renderCard(); }),
      authForm(mode)
    );
  };
  app.append(h("div", { class: "auth" },
    h("div", { class: "auth-brand" },
      h("img", { class: "auth-logo", src: "/static/icons/icon-192.png", alt: "" }),
      h("h1", null, "باهم"),
      h("p", { class: "tagline" }, "جای کوچیک و خصوصی برای دو نفر")),
    card,
    h("p", { class: "auth-note" }, "همه‌چیز فقط روی سرور خودتون می‌مونه و فقط شما دو نفر بهش دسترسی دارید.")));
  renderCard();
}

function authForm(mode) {
  const err = h("div", { class: "error-text", role: "alert" });
  const nameIn = h("input", { type: "text", name: "username", autocomplete: "username", maxLength: 30, required: true, placeholder: "مثلاً مهدی" });
  const pwIn = h("input", { type: "password", name: "password", autocomplete: mode === "login" ? "current-password" : "new-password", required: true, minLength: 6 });
  const codeIn = h("input", { type: "text", class: "ltr", autocomplete: "off", autocapitalize: "characters", maxLength: 12, required: true, placeholder: "ABC123", dir: "ltr" });
  const picker = jalaliPicker(null, { minYear: J.isoToJ(todayIso()).jy - 40, maxYear: J.isoToJ(todayIso()).jy });
  const labels = { create: "ساخت فضای ما", join: "پیوستن", login: "ورود" };

  // ورود: انتخاب با یه ضربه بین اسم خودت و اسم شریکت
  const nameSlot = h("div");
  let chosen = null;
  const getName = () => (chosen !== null ? chosen : nameIn.value);
  if (mode === "login") {
    nameSlot.append(field("نام", nameIn));
    api("GET", "/api/members", undefined, { noAuthRedirect: true }).then(({ names }) => {
      if (!names.length || !nameSlot.isConnected) return;
      let last = null;
      try { last = localStorage.getItem("bahamm.lastname"); } catch { /* ignore */ }
      chosen = names.includes(last) ? last : names.length === 1 ? names[0] : null;
      const grid = h("div", { class: "who", role: "radiogroup", "aria-label": "تو کی هستی؟" });
      const paint = () => [...grid.children].forEach((b) => b.setAttribute("aria-checked", String(b.dataset.name === chosen)));
      names.forEach((n) => grid.append(h("button", { type: "button", class: "who-btn", role: "radio", "data-name": n, "aria-checked": "false",
        onclick: () => { chosen = n; paint(); pwIn.focus(); } },
        h("span", { class: "who-av", "aria-hidden": "true" }, [...n][0] || "؟"), h("span", { class: "who-name" }, n))));
      paint();
      nameSlot.textContent = "";
      nameSlot.append(h("div", { class: "field" }, h("div", { class: "lbl" }, "تو کی هستی؟"), grid));
    }).catch(() => { /* اگه نشد، همون ورودی متنی می‌مونه */ });
  }
  const submit = h("button", { class: "btn block", type: "submit" }, labels[mode]);
  const form = h("form", { novalidate: true, onsubmit: async (e) => {
    e.preventDefault();
    err.textContent = "";
    try {
      await withBusy(submit, "صبر کن…", async () => {
        let me;
        if (mode === "create") me = await api("POST", "/api/create", { name: nameIn.value, password: pwIn.value, start_date: picker.get() }, { noAuthRedirect: true });
        else if (mode === "join") me = await api("POST", "/api/join", { code: en(codeIn.value), name: nameIn.value, password: pwIn.value }, { noAuthRedirect: true });
        else {
          if (!getName().trim()) throw new Error("اول انتخاب کن کدوم یکی از شما هستی");
          me = await api("POST", "/api/login", { name: getName(), password: pwIn.value }, { noAuthRedirect: true });
        }
        localStorage.setItem("bahamm.known", "1");
        try { localStorage.setItem("bahamm.lastname", me.user.name); } catch { /* ignore */ }
        setMe(me);
        start();
      });
    } catch (ex) { err.textContent = ex.message; }
  } });
  form.append(...[
    mode === "join" ? field("کد دعوت", codeIn, "کدی که شریکت برات فرستاده") : null,
    mode === "login" ? nameSlot : field("نام تو", nameIn),
    field("رمز عبور", pwIn, mode === "login" ? null : "حداقل ۶ کاراکتر"),
    mode === "create" ? field("تاریخ شروع رابطه", picker.el) : null,
    err,
    submit
  ].filter(Boolean));
  return form;
}

/* ======================================================= shell + router */
function mountShell() {
  const app = $("#app");
  app.className = "app";
  app.textContent = "";
  const tabs = [["home", "خانه", "home"], ["chat", "گفتگو", "chat"], ["memories", "خاطره‌ها", "image"], ["plans", "برنامه‌ها", "list"]];
  const bar = h("nav", { class: "tabbar", "aria-label": "منوی اصلی" },
    tabs.map(([r, label, ic]) => h("button", { class: "tab", type: "button", "data-route": r, onclick: () => go(r) },
      h("span", { class: "pill" }, icon(ic), r === "chat" ? h("span", { class: "badge", id: "chat-badge", hidden: true }) : null), label)));
  app.append(h("main", { class: "view", id: "view" }), bar);
}
const go = (r) => { if (location.hash === `#/${r}`) route(); else location.hash = `#/${r}`; };

const VIEWS = { home: viewHome, chat: viewChat, memories: viewMemories, plans: viewPlans, settings: viewSettings };
function route() {
  if (!S.user) return;
  const name = (location.hash.replace(/^#\/?/, "") || "home").split("/")[0];
  S.route = VIEWS[name] ? name : "home";
  S.viewToken += 1;
  stopTimers();
  const view = $("#view");
  view.className = "view" + (S.route === "chat" ? " flush" : "");
  view.textContent = "";
  view.scrollTop = 0;
  document.querySelectorAll(".tab").forEach((t) => {
    const on = t.dataset.route === S.route;
    t.classList.toggle("on", on);
    if (on) t.setAttribute("aria-current", "page"); else t.removeAttribute("aria-current");
  });
  VIEWS[S.route](view, S.viewToken);
  applyTyping();
}

// کیبورد باز ⇒ نوار پایین فقط توی گفتگو مخفی می‌شه (نه بر اساس فوکوس، تا هیچ‌وقت گیر نکنه)
function applyTyping() {
  const app = $(".app");
  if (!app) return;
  const vv = window.visualViewport;
  const kb = !!vv && isTouch() && window.innerHeight - vv.height > 120;
  app.classList.toggle("typing", kb && S.route === "chat");
}
function syncVH() {
  const vv = window.visualViewport;
  document.documentElement.style.setProperty("--vh", `${vv ? vv.height : window.innerHeight}px`);
  if (window.scrollY) window.scrollTo(0, 0);
  applyTyping();
}

async function start() {
  mountShell();
  updateBadge();
  route();
  S.lastId = 0; S.unread = 0;
  await refreshUnread(true);
  if (S.bg) clearInterval(S.bg);
  S.bg = setInterval(() => { if (!document.hidden && S.route !== "chat") refreshUnread(); }, 15000);
}

async function boot() {
  syncVH();
  if (window.visualViewport) { visualViewport.addEventListener("resize", syncVH); visualViewport.addEventListener("scroll", syncVH); }
  addEventListener("resize", syncVH);
  addEventListener("hashchange", route);
  addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); S.installPrompt = e; });
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && S.user && !sheetOpen() && ["home", "memories", "plans"].includes(S.route)) route();
  });
  try {
    setMe(await api("GET", "/api/me", undefined, { noAuthRedirect: true }));
    start();
  } catch (e) {
    if (e.status === 401) showAuth();
    else {
      const app = $("#app");
      app.textContent = "";
      app.append(h("div", { class: "auth" }, h("div", { class: "auth-brand" }, h("h1", null, "باهم"), h("p", { class: "tagline" }, e.message)),
        h("button", { class: "btn block", type: "button", onclick: () => location.reload() }, "تلاش دوباره")));
    }
  }
}

/* ======================================================= home */
function greeting() {
  const hr = new Date().getHours();
  if (hr < 5) return "شب بخیر";
  if (hr < 12) return "صبح بخیر";
  if (hr < 17) return "روز بخیر";
  if (hr < 20) return "عصر بخیر";
  return "شب بخیر";
}

function heroCard() {
  const { start_date: start } = S.couple;
  const today = todayIso();
  const p = partner();
  const pair = h("div", { class: "hero-pair" }, S.user.name, icon("heart", true), p ? p.name : "منتظر شریکت");
  if (!start) {
    return h("section", { class: "hero" }, pair, h("p", { style: { margin: "14px 0" } }, "تاریخ شروع رابطه‌تون رو تنظیم کنید تا شمارش شروع بشه."),
      h("button", { class: "btn small", type: "button", style: { background: "var(--saffron)", color: "#1b2150" }, onclick: () => go("settings") }, "تنظیم تاریخ"));
  }
  const days = diffDays(start, today);
  if (days < 0) {
    return h("section", { class: "hero" }, pair,
      h("div", { class: "hero-count" }, h("b", null, fa(-days)), h("span", null, "روز تا شروع")),
      h("div", { class: "hero-since" }, `شروع: ${fmtDate(start, { weekday: true })}`));
  }
  const { y, m, d } = ymd(start, today);
  const sj = J.isoToJ(start);
  let target = nextOcc(start, today);
  if (J.isoToJ(target).jy <= sj.jy) target = annOn(start, sj.jy + 1);
  const n = J.isoToJ(target).jy - sj.jy;
  const prev = annOn(start, J.isoToJ(target).jy - 1);
  const span = Math.max(1, diffDays(prev, target));
  const progress = Math.min(1, Math.max(0, diffDays(prev, today) / span));
  const left = diffDays(today, target);
  const mile = days === 0 ? 100 : Math.ceil(days / 100) * 100;
  const mileLeft = mile - days;
  return h("section", { class: "hero" }, pair,
    h("div", { class: "hero-count" }, h("b", null, fa(days)), h("span", null, days === 0 ? "امروز شروعه" : "روز با هم")),
    h("div", { class: "hero-since" }, `از ${fmtDate(start, { weekday: true })}`),
    h("div", { class: "ymd" },
      h("div", null, h("b", null, fa(y)), h("small", null, "سال")),
      h("div", null, h("b", null, fa(m)), h("small", null, "ماه")),
      h("div", null, h("b", null, fa(d)), h("small", null, "روز"))),
    h("div", { class: "next" },
      h("div", { class: "next-line" }, h("span", null, `سالگرد ${ordinal(n)}`), h("strong", null, left === 0 ? "امروزه!" : `${fa(left)} روز مونده`)),
      h("div", { class: "track", role: "progressbar", "aria-valuenow": Math.round(progress * 100), "aria-valuemin": 0, "aria-valuemax": 100 }, h("div", { class: "fill", style: { width: `${Math.round(progress * 100)}%` } })),
      h("div", { class: "next-line", style: { marginTop: "10px", marginBottom: 0 } }, h("span", null, `${fa(mile)} روزگی`), h("strong", null, mileLeft === 0 ? "امروزه!" : `${fa(mileLeft)} روز مونده`))));
}

function inviteCard() {
  const code = S.couple.invite_code;
  const pretty = `${code.slice(0, 3)}-${code.slice(3)}`;
  return h("section", { class: "card invite" },
    h("div", { class: "card-title" }, "شریکت رو دعوت کن"),
    h("p", null, "این کد رو براش بفرست. توی اپ «پیوستن» رو بزنه و کد رو وارد کنه."),
    h("span", { class: "code", dir: "ltr" }, pretty),
    h("div", { class: "btn-row" },
      h("button", { class: "btn secondary", type: "button", onclick: async () => toast((await copyText(code)) ? "کد کپی شد" : "کپی نشد") }, icon("copy"), "کپی کد"),
      h("button", { class: "btn", type: "button", onclick: () => shareInvite(code) }, icon("share"), "ارسال دعوت")));
}

function installCard() {
  if (isStandalone() || localStorage.getItem("bahamm.noinstall")) return null;
  const card = h("section", { class: "card" },
    h("div", { class: "card-title" }, "نصب روی گوشی", h("button", { type: "button", "aria-label": "نبینمش", onclick: () => { localStorage.setItem("bahamm.noinstall", "1"); card.remove(); } }, "بعداً")),
    h("p", { class: "sub", style: { marginBottom: "12px" } }, "با نصب، «باهم» مثل یه اپ معمولی از صفحه‌ی اصلی گوشی باز می‌شه."),
    h("button", { class: "btn small", type: "button", onclick: () => installFlow() }, "نصب کنم"));
  return card;
}
async function installFlow() {
  if (S.installPrompt) {
    S.installPrompt.prompt();
    try { await S.installPrompt.userChoice; } catch { /* ignore */ }
    S.installPrompt = null;
    return;
  }
  openSheet("نصب روی گوشی", (body) => {
    body.append(h("div", { class: "set-group" },
      h("h3", null, "آیفون (Safari)"),
      h("ol", { class: "steps" },
        h("li", null, "این صفحه رو حتماً توی Safari باز کن، نه داخل اپ دیگه."),
        h("li", null, "دکمه‌ی اشتراک‌گذاری پایین صفحه (مربع با فلش رو به بالا) رو بزن."),
        h("li", null, "گزینه‌ی «Add to Home Screen» رو انتخاب کن."),
        h("li", null, "«Add» رو بزن."))),
      h("div", { class: "set-group" },
        h("h3", null, "اندروید (Chrome)"),
        h("ol", { class: "steps" },
          h("li", null, "منوی سه‌نقطه‌ی بالای Chrome رو بزن."),
          h("li", null, "«Install app» یا «Add to Home screen» رو انتخاب کن."),
          h("li", null, "نصب رو تأیید کن."))));
  });
}

async function viewHome(el, token) {
  const today = todayIso();
  el.append(
    h("div", { class: "page-head" },
      h("div", null, h("div", { class: "sub" }, fmtDate(today, { weekday: true })), h("h1", { class: "page-title" }, `${greeting()}، ${S.user.name}`)),
      h("button", { class: "icon-btn", type: "button", "aria-label": "تنظیمات", onclick: () => go("settings") }, icon("sliders"))));
  const stack = h("div", { class: "stack" }, heroCard());
  el.append(stack);
  const slot = h("div", { class: "stack" });
  stack.append(slot);

  try {
    const [me, plans, occ, mem] = await Promise.all([
      api("GET", "/api/me"), api("GET", "/api/plans"), api("GET", "/api/occasions"), api("GET", "/api/memories"),
    ]);
    if (token !== S.viewToken) return;
    const changed = JSON.stringify(me.couple) !== JSON.stringify(S.couple);
    S.couple = me.couple;
    if (changed) { stack.firstChild.replaceWith(heroCard()); }
    if (!S.couple.complete) slot.append(inviteCard());

    const items = [];
    if (S.couple.start_date) {
      const sj = J.isoToJ(S.couple.start_date);
      let t = nextOcc(S.couple.start_date, today);
      if (J.isoToJ(t).jy <= sj.jy) t = annOn(S.couple.start_date, sj.jy + 1);
      items.push({ date: t, title: `سالگرد ${ordinal(J.isoToJ(t).jy - sj.jy)} ما`, sub: "خودکار" });
    }
    occ.occasions.forEach((o) => items.push({ date: o.yearly ? nextOcc(o.date, today) : o.date, title: o.title, sub: o.yearly ? "هر سال" : "" }));
    plans.plans.filter((p) => !p.done && p.due_date && p.due_date >= today).forEach((p) => items.push({ date: p.due_date, title: p.title, sub: "برنامه" }));
    const upcoming = items.filter((i) => i.date >= today).sort((a, b) => (a.date < b.date ? -1 : 1)).slice(0, 4);
    if (upcoming.length) {
      slot.append(h("section", { class: "card" },
        h("div", { class: "card-title" }, "پیش رو", h("button", { type: "button", onclick: () => go("plans") }, "همه‌ی برنامه‌ها")),
        upcoming.map((i) => {
          const dd = diffDays(today, i.date), j = J.isoToJ(i.date);
          return h("div", { class: "row" },
            h("div", { class: "date-tile" + (dd <= 7 ? " hot" : "") }, h("b", null, fa(j.jd)), h("small", null, MONTHS[j.jm - 1])),
            h("div", { class: "grow" }, h("div", { class: "t" }, i.title), h("div", { class: "s" }, [relDays(dd), i.sub].filter(Boolean).join(" · "))));
        })));
    }
    const withPhoto = mem.memories.filter((m) => m.photo);
    if (withPhoto.length) {
      const m = withPhoto[Math.floor(Math.random() * withPhoto.length)];
      slot.append(h("button", { class: "card album-card", type: "button", onclick: () => go("memories") },
        h("img", { src: `/api/photo/${m.id}?s=t&v=${m.photo}`, alt: m.title || "خاطره", loading: "lazy" }),
        h("div", { class: "cap" }, h("b", null, m.title || "یه خاطره"), h("span", { class: "sub" }, fmtDate(m.date)))));
    }
    const ins = installCard();
    if (ins) slot.append(ins);
  } catch (e) { if (token === S.viewToken) fail(e); }
}

/* ======================================================= chat + notes */
function viewChat(el, token) {
  const panel = h("div", { class: "panel" });
  const swap = (tab) => {
    S.chatTab = tab;
    stopTimers();
    S.viewToken += 1;
    panel.textContent = "";
    if (tab === "chat") chatPanel(panel, S.viewToken); else notesPanel(panel, S.viewToken);
  };
  el.append(h("div", { class: "chat-top" }, segmented([["chat", "گفتگو"], ["notes", "یادداشت‌ها"]], S.chatTab, swap)), panel);
  if (S.chatTab === "chat") chatPanel(panel, token); else notesPanel(panel, token);
}

function chatPanel(panel, token) {
  const scroll = h("div", { class: "chat-scroll", role: "log", "aria-live": "polite" });
  const ta = h("textarea", { rows: 1, placeholder: "یه پیام بنویس…", dir: "auto", "aria-label": "پیام", enterKeyHint: "send", maxLength: 2000 });
  const sendBtn = h("button", { class: "icon-btn", type: "button", "aria-label": "ارسال" }, icon("send"));
  const pill = h("button", { class: "btn small newpill", type: "button", hidden: true, onclick: () => { toBottom(); } }, icon("down"), "پیام جدید");
  panel.append(scroll, pill, h("div", { class: "composer" }, ta, sendBtn));

  const known = new Set();
  let msgs = [];
  let hasMore = false;
  let last = null; // آخرین پیام رندرشده برای گروه‌بندی
  const nearBottom = () => scroll.scrollHeight - scroll.scrollTop - scroll.clientHeight < 140;
  const toBottom = () => { scroll.scrollTop = scroll.scrollHeight; pill.hidden = true; };
  const dayLabel = (iso) => {
    const t = todayIso();
    if (iso === t) return "امروز";
    if (diffDays(iso, t) === 1) return "دیروز";
    return fmtDate(iso, { weekday: true, year: J.isoToJ(iso).jy !== J.isoToJ(t).jy });
  };
  function bubble(m, prev) {
    const day = localIso(new Date(m.created_at));
    const nodes = [];
    if (!prev || localIso(new Date(prev.created_at)) !== day) nodes.push(h("div", { class: "daysep" }, dayLabel(day)));
    const mine = m.user_id === S.user.id;
    const cont = prev && prev.user_id === m.user_id && nodes.length === 0 && new Date(m.created_at) - new Date(prev.created_at) < 5 * 60000;
    nodes.push(h("div", { class: `msg ${mine ? "mine" : "theirs"}${cont ? " cont" : ""}${m.pending ? " pending" : ""}`, "data-id": m.id },
      h("div", { dir: "auto" }, m.body), h("span", { class: "msg-time" }, timeFa(m.created_at))));
    return nodes;
  }
  function renderAll() {
    scroll.textContent = "";
    if (hasMore) scroll.append(h("button", { class: "btn ghost small older", type: "button", onclick: loadOlder }, "پیام‌های قدیمی‌تر"));
    if (!msgs.length) { scroll.append(emptyState("هنوز پیامی نیست", "اولین پیام رو بفرست.")); last = null; return; }
    let prev = null;
    msgs.forEach((m) => { scroll.append(...bubble(m, prev)); prev = m; });
    last = prev;
  }
  function addMessages(list) {
    const fresh = list.filter((m) => !known.has(m.id));
    if (!fresh.length) return;
    const stick = nearBottom();
    const wasEmpty = !msgs.length;
    fresh.forEach((m) => { known.add(m.id); msgs.push(m); S.lastId = Math.max(S.lastId, m.id); });
    if (wasEmpty) renderAll();
    else fresh.forEach((m) => { scroll.append(...bubble(m, last)); last = m; });
    const mineLast = fresh[fresh.length - 1].user_id === S.user.id;
    if (stick || mineLast) toBottom(); else pill.hidden = false;
    if (document.visibilityState === "visible") markSeen(S.lastId);
  }
  async function loadOlder() {
    if (!msgs.length) return;
    try {
      const r = await api("GET", `/api/messages?before=${msgs[0].id}&limit=60`);
      const h0 = scroll.scrollHeight;
      r.messages.forEach((m) => known.add(m.id));
      msgs = [...r.messages, ...msgs];
      hasMore = r.has_more;
      renderAll();
      scroll.scrollTop = scroll.scrollHeight - h0;
    } catch (e) { fail(e); }
  }
  async function poll() {
    if (document.hidden || token !== S.viewToken) return;
    try { addMessages((await api("GET", `/api/messages?after=${S.lastId}`)).messages); } catch { /* بی‌صدا */ }
  }
  const autosize = () => { ta.style.height = "auto"; ta.style.height = `${Math.min(ta.scrollHeight, 132)}px`; };
  async function doSend() {
    const text = ta.value.trim();
    if (!text) return;
    ta.value = ""; autosize();
    if (!msgs.length) scroll.textContent = "";
    const tmp = h("div", { class: "msg mine pending" }, h("div", { dir: "auto" }, text), h("span", { class: "msg-time" }, "…"));
    scroll.append(tmp); toBottom();
    try {
      const m = await api("POST", "/api/messages", { body: text });
      tmp.remove();
      addMessages([m]);
    } catch (e) {
      tmp.remove();
      ta.value = text; autosize();
      fail(e);
    }
    if (isTouch()) ta.focus();
  }
  sendBtn.addEventListener("pointerdown", (e) => e.preventDefault());
  sendBtn.addEventListener("click", doSend);
  ta.addEventListener("input", autosize);
  ta.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey && !isTouch()) { e.preventDefault(); doSend(); } });
  ta.addEventListener("focus", () => { if (isTouch()) setTimeout(toBottom, 300); });
  scroll.addEventListener("scroll", () => { if (nearBottom()) pill.hidden = true; });

  scroll.append(h("div", { class: "spinner", role: "status", "aria-label": "در حال بارگذاری" }));
  api("GET", "/api/messages?limit=60").then((r) => {
    if (token !== S.viewToken) return;
    msgs = r.messages; hasMore = r.has_more;
    msgs.forEach((m) => { known.add(m.id); S.lastId = Math.max(S.lastId, m.id); });
    renderAll(); toBottom(); markSeen(S.lastId);
  }).catch((e) => { scroll.textContent = ""; scroll.append(emptyState("پیام‌ها بالا نیومد", e.message, "تلاش دوباره", () => viewChatReload())); });
  every(3000, poll);
}
const viewChatReload = () => route();

function notesPanel(panel, token) {
  const list = h("div", { class: "chat-scroll", style: { padding: "6px 18px 24px", display: "block" } });
  panel.append(list);
  const load = async () => {
    try {
      const { notes } = await api("GET", "/api/notes");
      if (token !== S.viewToken) return;
      list.textContent = "";
      list.append(h("button", { class: "btn block secondary", type: "button", style: { marginBottom: "14px" }, onclick: () => openNoteSheet(null, load) }, icon("plus"), "یادداشت جدید"));
      if (!notes.length) { list.append(emptyState("هنوز یادداشتی ننوشتید", "چیزهایی که نباید یادتون بره، اینجا جمع می‌شن.")); return; }
      notes.forEach((n) => list.append(h("button", { class: "note" + (n.pinned ? " pinned" : ""), type: "button", onclick: () => openNoteSheet(n, load) },
        n.title ? h("h3", { dir: "auto" }, n.title) : null,
        n.body ? h("p", { dir: "auto" }, n.body) : null,
        h("div", { class: "meta" }, n.pinned ? icon("pin", true) : null, `${nameOf(n.user_id)} · ${fmtDate(localIso(new Date(n.updated_at)))}`))));
    } catch (e) { list.textContent = ""; list.append(emptyState("یادداشت‌ها بالا نیومد", e.message)); }
  };
  load();
}

function openNoteSheet(note, done) {
  openSheet(note ? "ویرایش یادداشت" : "یادداشت جدید", (body, close) => {
    const title = h("input", { type: "text", dir: "auto", maxLength: 120, value: note ? note.title : "", placeholder: "عنوان (اختیاری)" });
    const text = h("textarea", { dir: "auto", rows: 8, maxLength: 10000, value: note ? note.body : "", placeholder: "بنویس…" });
    const pin = toggleRow("سنجاق به بالای فهرست", note && note.pinned);
    const save = h("button", { class: "btn", type: "button", onclick: () => withBusy(save, "در حال ذخیره…", async () => {
      try {
        const payload = { title: title.value, body: text.value, pinned: pin.get() };
        if (note) await api("PUT", `/api/notes/${note.id}`, payload); else await api("POST", "/api/notes", payload);
        close(); done();
      } catch (e) { fail(e); }
    }) }, "ذخیره");
    body.append(field("عنوان", title), field("متن", text), pin.el,
      h("div", { class: "btn-row" }, save,
        note ? h("button", { class: "btn danger", type: "button", onclick: async () => {
          if (!(await confirmDialog("حذف یادداشت؟", "این یادداشت برای هر دو نفرتون پاک می‌شه.", "حذف", true))) return;
          try { await api("DELETE", `/api/notes/${note.id}`); close(); done(); } catch (e) { fail(e); }
        } }, icon("trash"), "حذف") : null));
  });
}

/* ======================================================= memories */
async function shrinkImage(file, maxDim = 2000) {
  try {
    if (file.size < 900 * 1024 && /jpe?g/i.test(file.type)) return file;
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.src = url;
    await img.decode();
    const k = Math.min(1, maxDim / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement("canvas");
    c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
    c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
    URL.revokeObjectURL(url);
    const blob = await new Promise((res) => c.toBlob(res, "image/jpeg", 0.86));
    return blob || file;
  } catch { return file; }
}

async function viewMemories(el, token) {
  el.append(h("div", { class: "page-head" }, h("h1", { class: "page-title" }, "خاطره‌ها"),
    h("button", { class: "icon-btn primary", type: "button", "aria-label": "افزودن خاطره", onclick: () => openMemoryForm(null, () => route()) }, icon("plus"))));
  const body = h("div", null, h("div", { class: "spinner", role: "status", "aria-label": "در حال بارگذاری" }));
  el.append(body);
  try {
    const { memories } = await api("GET", "/api/memories");
    if (token !== S.viewToken) return;
    body.textContent = "";
    if (!memories.length) { body.append(emptyState("آلبوم خالیه", "اولین خاطره‌تون رو با یه عکس اضافه کنید.", "افزودن خاطره", () => openMemoryForm(null, () => route()))); return; }
    let key = "", grid = null;
    memories.forEach((m) => {
      const j = J.isoToJ(m.date), k = `${j.jy}-${j.jm}`;
      if (k !== key) { key = k; body.append(h("div", { class: "group-title" }, `${MONTHS[j.jm - 1]} ${fa(j.jy)}`)); grid = h("div", { class: "mem-grid" }); body.append(grid); }
      grid.append(m.photo
        ? h("button", { class: "mem", type: "button", onclick: () => openMemoryDetail(m) },
            h("img", { src: `/api/photo/${m.id}?s=t&v=${m.photo}`, alt: m.title || "خاطره", loading: "lazy" }),
            h("div", { class: "cap" }, m.title ? h("b", null, m.title) : null, h("small", null, fmtDate(m.date))))
        : h("button", { class: "mem text", type: "button", onclick: () => openMemoryDetail(m) },
            h("b", { dir: "auto" }, m.title || m.body), h("small", null, fmtDate(m.date))));
    });
  } catch (e) { body.textContent = ""; body.append(emptyState("خاطره‌ها بالا نیومد", e.message, "تلاش دوباره", () => route())); }
}

function openMemoryDetail(m) {
  openSheet("خاطره", (body, close) => {
    body.append(h("div", { class: "detail" },
      m.photo ? h("img", { class: "detail-photo", src: `/api/photo/${m.id}?v=${m.photo}`, alt: m.title || "خاطره" }) : null,
      m.title ? h("h3", { dir: "auto" }, m.title) : null,
      h("div", { class: "when" }, `${fmtDate(m.date, { weekday: true })} · ${nameOf(m.user_id)}`),
      m.body ? h("p", { dir: "auto" }, m.body) : null),
      h("div", { class: "btn-row", style: { marginTop: "16px" } },
        h("button", { class: "btn secondary", type: "button", onclick: () => { close(); setTimeout(() => openMemoryForm(m, () => route()), 300); } }, icon("edit"), "ویرایش"),
        h("button", { class: "btn danger", type: "button", onclick: async () => {
          if (!(await confirmDialog("حذف خاطره؟", "این خاطره و عکسش برای هر دو نفرتون پاک می‌شه.", "حذف", true))) return;
          try { await api("DELETE", `/api/memories/${m.id}`); close(); route(); } catch (e) { fail(e); }
        } }, icon("trash"), "حذف")));
  });
}

function openMemoryForm(m, done) {
  openSheet(m ? "ویرایش خاطره" : "خاطره‌ی جدید", (body, close) => {
    let file = null, removePhoto = false;
    const input = h("input", { type: "file", accept: "image/*", hidden: true });
    const pick = h("button", { class: "photo-pick", type: "button", onclick: () => input.click() });
    const showPick = (src) => {
      pick.textContent = "";
      if (src) pick.append(h("img", { src, alt: "پیش‌نمایش" }));
      else pick.append(icon("camera"), h("span", null, "افزودن عکس"));
    };
    showPick(m && m.photo ? `/api/photo/${m.id}?s=t&v=${m.photo}` : null);
    input.addEventListener("change", () => {
      if (!input.files[0]) return;
      file = input.files[0]; removePhoto = false;
      showPick(URL.createObjectURL(file));
    });
    const title = h("input", { type: "text", dir: "auto", maxLength: 120, value: m ? m.title : "", placeholder: "مثلاً اولین قهوه‌مون" });
    const text = h("textarea", { dir: "auto", rows: 4, maxLength: 5000, value: m ? m.body : "", placeholder: "اون روز چی شد؟" });
    const dateP = jalaliPicker(m ? m.date : todayIso(), { minYear: J.isoToJ(todayIso()).jy - 40, maxYear: J.isoToJ(todayIso()).jy });
    const save = h("button", { class: "btn", type: "button", onclick: () => withBusy(save, "در حال ذخیره…", async () => {
      try {
        const fd = new FormData();
        fd.append("title", title.value); fd.append("body", text.value); fd.append("date", dateP.get());
        if (file) fd.append("photo", await shrinkImage(file), "photo.jpg");
        if (removePhoto) fd.append("remove_photo", "1");
        await api(m ? "PUT" : "POST", m ? `/api/memories/${m.id}` : "/api/memories", fd);
        close(); done();
      } catch (e) { fail(e); }
    }) }, "ذخیره");
    body.append(...[input, h("div", { class: "field" }, pick),
      m && m.photo ? h("button", { class: "btn ghost small", type: "button", style: { marginBottom: "10px" }, onclick: () => { removePhoto = true; file = null; showPick(null); } }, "حذف عکس") : null,
      field("عنوان", title), field("توضیح", text), field("تاریخ", dateP.el), h("div", { class: "btn-row" }, save)].filter(Boolean));
  });
}

/* ======================================================= plans + occasions */
const KINDS = { todo: ["کار", "✅"], trip: ["سفر", "✈️"], date: ["قرار", "🌹"], wish: ["آرزو", "✨"] };

function viewPlans(el, token) {
  const panel = h("div");
  const swap = (tab) => { S.plansTab = tab; S.viewToken += 1; panel.textContent = ""; (tab === "plans" ? plansPanel : occasionsPanel)(panel, S.viewToken); };
  el.append(h("div", { class: "page-head" }, h("h1", { class: "page-title" }, "برنامه‌ها")),
    segmented([["plans", "برنامه‌ها"], ["occasions", "مناسبت‌ها"]], S.plansTab, swap),
    h("div", { style: { height: "14px" } }), panel);
  (S.plansTab === "plans" ? plansPanel : occasionsPanel)(panel, token);
}

async function plansPanel(panel, token) {
  const today = todayIso();
  const input = h("input", { type: "text", dir: "auto", maxLength: 200, placeholder: "برنامه‌ی جدید…", "aria-label": "برنامه‌ی جدید", enterKeyHint: "done" });
  const addBtn = h("button", { class: "icon-btn primary", type: "button", "aria-label": "افزودن" }, icon("plus"));
  const list = h("div");
  panel.append(h("div", { class: "quick-add" }, input, addBtn), list);
  let plans = [];

  const render = () => {
    list.textContent = "";
    if (!plans.length) { list.append(emptyState("برنامه‌ای نیست", "یه سفر، یه قرار یا یه آرزو اضافه کنید.")); return; }
    const open = plans.filter((p) => !p.done);
    const dated = open.filter((p) => p.due_date).sort((a, b) => (a.due_date < b.due_date ? -1 : 1));
    const undated = open.filter((p) => !p.due_date);
    const done = plans.filter((p) => p.done);
    const section = (title, arr) => { if (arr.length) { list.append(h("div", { class: "section-title" }, title)); arr.forEach((p) => list.append(row(p))); } };
    section("با تاریخ", dated); section("بدون تاریخ", undated); section("انجام‌شده", done);
  };
  const row = (p) => {
    const [label, emoji] = KINDS[p.kind] || KINDS.todo;
    const chk = h("button", { class: "check" + (p.done ? " on" : ""), type: "button", role: "checkbox", "aria-checked": String(p.done), "aria-label": "انجام شد", onclick: async () => {
      const prev = p.done; p.done = !p.done; render();
      try { await api("PUT", `/api/plans/${p.id}`, { done: p.done }); } catch (e) { p.done = prev; render(); fail(e); }
    } }, icon("check"));
    const dd = p.due_date ? diffDays(today, p.due_date) : null;
    return h("div", { class: "plan" + (p.done ? " done" : "") }, chk,
      h("button", { class: "body", type: "button", onclick: () => openPlanSheet(p, reload) },
        h("div", { class: "t", dir: "auto" }, p.title),
        h("div", { class: "s" }, h("span", { class: `chip ${p.kind}` }, `${emoji} ${label}`),
          p.due_date ? h("span", null, `${fmtDate(p.due_date, { year: J.isoToJ(p.due_date).jy !== J.isoToJ(today).jy })}${p.done ? "" : ` · ${relDays(dd)}`}`) : null)));
  };
  const reload = async () => {
    try { plans = (await api("GET", "/api/plans")).plans; if (token === S.viewToken) render(); } catch (e) { list.textContent = ""; list.append(emptyState("برنامه‌ها بالا نیومد", e.message)); }
  };
  const quickAdd = async () => {
    const title = input.value.trim();
    if (!title) return;
    input.value = "";
    try { await api("POST", "/api/plans", { title, kind: "todo" }); await reload(); } catch (e) { input.value = title; fail(e); }
  };
  addBtn.addEventListener("click", quickAdd);
  input.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); quickAdd(); } });
  list.append(h("div", { class: "spinner", role: "status", "aria-label": "در حال بارگذاری" }));
  reload();
}

function openPlanSheet(plan, done) {
  openSheet(plan ? "ویرایش برنامه" : "برنامه‌ی جدید", (body, close) => {
    let kind = plan ? plan.kind : "todo";
    const title = h("input", { type: "text", dir: "auto", maxLength: 200, value: plan ? plan.title : "", placeholder: "مثلاً آخر هفته بریم شمال" });
    const kp = h("div", { class: "kind-pick" });
    const renderKinds = () => { kp.textContent = ""; Object.entries(KINDS).forEach(([k, [label, emoji]]) => kp.append(h("button", { type: "button", "aria-pressed": String(k === kind), onclick: () => { kind = k; renderKinds(); } }, `${emoji} ${label}`))); };
    renderKinds();
    const nowJ = J.isoToJ(todayIso()).jy;
    const date = optionalDate(plan && plan.due_date, { minYear: nowJ - 1, maxYear: nowJ + 5 });
    const save = h("button", { class: "btn", type: "button", onclick: () => withBusy(save, "در حال ذخیره…", async () => {
      try {
        const payload = { title: title.value, kind, due_date: date.get() };
        if (plan) await api("PUT", `/api/plans/${plan.id}`, payload); else await api("POST", "/api/plans", payload);
        close(); done();
      } catch (e) { fail(e); }
    }) }, "ذخیره");
    body.append(field("عنوان", title), h("div", { class: "field" }, h("div", { class: "lbl" }, "نوع"), kp), field("تاریخ", date.el),
      h("div", { class: "btn-row" }, save,
        plan ? h("button", { class: "btn danger", type: "button", onclick: async () => {
          if (!(await confirmDialog("حذف برنامه؟", "این برنامه از فهرست هر دو نفرتون پاک می‌شه.", "حذف", true))) return;
          try { await api("DELETE", `/api/plans/${plan.id}`); close(); done(); } catch (e) { fail(e); }
        } }, icon("trash"), "حذف") : null));
  });
}

async function occasionsPanel(panel, token) {
  const today = todayIso();
  const list = h("div");
  panel.append(h("button", { class: "btn block secondary", type: "button", style: { marginBottom: "6px" }, onclick: () => openOccasionSheet(null, load) }, icon("plus"), "مناسبت جدید"), list);
  const load = async () => {
    try {
      const { occasions } = await api("GET", "/api/occasions");
      if (token !== S.viewToken) return;
      const items = occasions.map((o) => ({ o, next: o.yearly ? nextOcc(o.date, today) : o.date }));
      if (S.couple.start_date) {
        const sj = J.isoToJ(S.couple.start_date);
        let t = nextOcc(S.couple.start_date, today);
        if (J.isoToJ(t).jy <= sj.jy) t = annOn(S.couple.start_date, sj.jy + 1);
        items.push({ o: { title: `سالگرد ${ordinal(J.isoToJ(t).jy - sj.jy)} ما`, date: S.couple.start_date, yearly: true, auto: true }, next: t });
      }
      items.sort((a, b) => (a.next < b.next ? -1 : 1));
      list.textContent = "";
      if (!items.length) { list.append(emptyState("مناسبتی ثبت نشده", "تولدها و روزهای مهم‌تون رو اضافه کنید.")); return; }
      items.forEach(({ o, next }) => {
        const dd = diffDays(today, next), j = J.isoToJ(next);
        list.append(h("div", { class: "row", style: { cursor: o.auto ? "default" : "pointer" }, onclick: o.auto ? null : () => openOccasionSheet(o, load) },
          h("div", { class: "date-tile" + (dd >= 0 && dd <= 7 ? " hot" : "") }, h("b", null, fa(j.jd)), h("small", null, MONTHS[j.jm - 1])),
          h("div", { class: "grow" }, h("div", { class: "t", dir: "auto" }, o.title),
            h("div", { class: "s" }, [dd >= 0 ? relDays(dd) : `${fa(-dd)} روز پیش`, o.auto ? "خودکار" : o.yearly ? "هر سال" : "یک‌بار"].join(" · ")))));
      });
    } catch (e) { list.textContent = ""; list.append(emptyState("مناسبت‌ها بالا نیومد", e.message)); }
  };
  load();
}

function openOccasionSheet(o, done) {
  openSheet(o ? "ویرایش مناسبت" : "مناسبت جدید", (body, close) => {
    const title = h("input", { type: "text", dir: "auto", maxLength: 120, value: o ? o.title : "", placeholder: "مثلاً تولد سارا" });
    const quick = h("div", { class: "kind-pick", style: { marginTop: "8px" } }, ["تولد", "سالگرد", "ماهگرد", "اولین دیدار"].map((t) => h("button", { type: "button", "aria-pressed": "false", onclick: () => { title.value = title.value ? `${t} ${title.value}` : t; } }, t)));
    const nowJ = J.isoToJ(todayIso()).jy;
    const date = jalaliPicker(o ? o.date : todayIso(), { minYear: nowJ - 80, maxYear: nowJ + 5 });
    const yearly = toggleRow("هر سال تکرار بشه", o ? o.yearly : true);
    const save = h("button", { class: "btn", type: "button", onclick: () => withBusy(save, "در حال ذخیره…", async () => {
      try {
        const payload = { title: title.value, date: date.get(), yearly: yearly.get() };
        if (o) await api("PUT", `/api/occasions/${o.id}`, payload); else await api("POST", "/api/occasions", payload);
        close(); done();
      } catch (e) { fail(e); }
    }) }, "ذخیره");
    body.append(h("div", { class: "field" }, h("div", { class: "lbl" }, "عنوان"), title, quick), field("تاریخ", date.el), yearly.el,
      h("div", { class: "btn-row" }, save,
        o ? h("button", { class: "btn danger", type: "button", onclick: async () => {
          if (!(await confirmDialog("حذف مناسبت؟", "این مناسبت پاک می‌شه.", "حذف", true))) return;
          try { await api("DELETE", `/api/occasions/${o.id}`); close(); done(); } catch (e) { fail(e); }
        } }, icon("trash"), "حذف") : null));
  });
}

/* ======================================================= settings */
function viewSettings(el) {
  el.append(h("div", { class: "page-head" },
    h("button", { class: "icon-btn", type: "button", "aria-label": "بازگشت", onclick: () => go("home") }, icon("back")),
    h("h1", { class: "page-title" }, "تنظیمات"), h("span", { style: { width: "44px" } })));
  const stack = h("div", { class: "stack" });
  el.append(stack);

  // نام
  const nameIn = h("input", { type: "text", maxLength: 30, value: S.user.name, autocomplete: "off" });
  const nameBtn = h("button", { class: "btn small", type: "button", onclick: () => withBusy(nameBtn, "در حال ذخیره…", async () => {
    try { setMe(await api("PATCH", "/api/me", { name: nameIn.value })); toast("نام ذخیره شد"); } catch (e) { fail(e); }
  }) }, "ذخیره‌ی نام");
  stack.append(h("section", { class: "card" }, h("div", { class: "set-group", style: { margin: 0 } }, h("h3", null, "نام تو"), field("نام نمایشی و ورود", nameIn), nameBtn)));

  // تاریخ شروع
  const nowJ = J.isoToJ(todayIso()).jy;
  const sp = jalaliPicker(S.couple.start_date || todayIso(), { minYear: nowJ - 40, maxYear: nowJ + 1 });
  const startBtn = h("button", { class: "btn small", type: "button", onclick: () => withBusy(startBtn, "در حال ذخیره…", async () => {
    try { S.couple = await api("PATCH", "/api/couple", { start_date: sp.get() }); toast("تاریخ شروع ذخیره شد"); } catch (e) { fail(e); }
  }) }, "ذخیره‌ی تاریخ");
  stack.append(h("section", { class: "card" }, h("div", { class: "set-group", style: { margin: 0 } }, h("h3", null, "تاریخ شروع رابطه"), h("div", { class: "field" }, sp.el), startBtn)));

  // دعوت
  if (!S.couple.complete && S.couple.invite_code) stack.append(inviteCard());

  // رمز
  const oldPw = h("input", { type: "password", autocomplete: "current-password" });
  const newPw = h("input", { type: "password", autocomplete: "new-password", minLength: 6 });
  const pwBtn = h("button", { class: "btn small secondary", type: "button", onclick: () => withBusy(pwBtn, "در حال ذخیره…", async () => {
    try { await api("PATCH", "/api/me", { old_password: oldPw.value, new_password: newPw.value }); oldPw.value = ""; newPw.value = ""; toast("رمز عبور عوض شد"); } catch (e) { fail(e); }
  }) }, "تغییر رمز");
  stack.append(h("section", { class: "card" }, h("div", { class: "set-group", style: { margin: 0 } }, h("h3", null, "رمز عبور"), field("رمز فعلی", oldPw), field("رمز جدید", newPw, "حداقل ۶ کاراکتر"), pwBtn)));

  // نصب
  stack.append(h("section", { class: "card" }, h("div", { class: "set-group", style: { margin: 0 } }, h("h3", null, "نصب روی گوشی"),
    h("p", { class: "sub", style: { marginBottom: "12px" } }, isStandalone() ? "اپ همین الان نصب شده." : "برای باز شدن از صفحه‌ی اصلی گوشی، نصبش کن."),
    isStandalone() ? null : h("button", { class: "btn small secondary", type: "button", onclick: installFlow }, isIOS() ? "راهنمای آیفون" : "نصب یا راهنما"))));

  // خروج
  stack.append(h("button", { class: "btn block secondary", type: "button", onclick: async () => {
    if (!(await confirmDialog("خروج از حساب؟", "اطلاعاتتون سر جاشون می‌مونه و هر وقت خواستید دوباره وارد می‌شید.", "خروج"))) return;
    try { await api("POST", "/api/logout", {}, { noAuthRedirect: true }); } catch { /* ignore */ }
    showAuth();
  } }, "خروج از حساب"));
}

/* ======================================================= boot */
if ("serviceWorker" in navigator) addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(() => {}));
boot();
})();
